
				<footer class="dashboard__footer"></footer>
			</div>
		</div>
		<script src="../assets/js/chart.js"></script>
		<script src="../assets/js/apexcharts.js"></script>
	</body>
</html>
