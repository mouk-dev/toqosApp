
				<footer class="dashboard__footer"></footer>
			</div>
		</div>
		<script src="delete-devise.js"></script>
	</body>
</html>
