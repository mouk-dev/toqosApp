
				<footer class="dashboard__footer"></footer>
			</div>
		</div>
		<script src="delete-caisse.js"></script>
	</body>
</html>
