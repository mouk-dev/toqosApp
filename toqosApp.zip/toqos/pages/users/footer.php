
				<footer class="dashboard__footer"></footer>
			</div>
		</div>
		<script src="delete-user.js"></script>
	</body>
</html>
